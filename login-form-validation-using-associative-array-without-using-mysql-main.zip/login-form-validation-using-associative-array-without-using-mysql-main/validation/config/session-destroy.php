<?php
    session_destroy();
?>